from setuptools import setup

setup(
    name='meupacote',
    packages=['package']
)