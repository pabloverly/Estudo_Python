def minha__lib():
    print("teste")

